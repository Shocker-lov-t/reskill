from django.http import HttpResponse
# Create your views here.
def index(request):
    return HttpResponse("AWS Community Builder <br><Strong><Font size='6'>TAPAS SINGHAL</font><strong>")